# Personal Finance Tracker

Full-stack app with React, TypeScript, Express, and SQLite.

## Quick Start
```bash
cd backend && npm install && npm run dev
cd frontend && npm install && npm run dev
```
