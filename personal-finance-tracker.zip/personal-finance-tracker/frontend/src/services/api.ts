const API_BASE = import.meta.env.VITE_API_BASE_URL || 'http://localhost:3000/api';
export async function fetchCategories() { const r = await fetch(`${API_BASE}/categories`); return (await r.json()).data; }
export async function fetchTransactions() { const r = await fetch(`${API_BASE}/transactions`); return (await r.json()).data; }
export async function createTransaction(data: any) { const r = await fetch(`${API_BASE}/transactions`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) }); return (await r.json()).data; }
export async function deleteTransaction(id: number) { const r = await fetch(`${API_BASE}/transactions/${id}`, { method: 'DELETE' }); return (await r.json()).data; }