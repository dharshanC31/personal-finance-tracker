import React, { useState, useEffect } from 'react'; import { fetchCategories, fetchTransactions, createTransaction, deleteTransaction } from './services/api';
export default function App() {
  const [categories, setCategories] = useState<any[]>([]);
  const [transactions, setTransactions] = useState<any[]>([]);
  const [amount, setAmount] = useState(''); const [categoryId, setCategoryId] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]); const [description, setDescription] = useState('');
  const loadData = async () => { setCategories(await fetchCategories()); setTransactions(await fetchTransactions()); };
  useEffect(() => { loadData(); }, []);
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await createTransaction({ amount: parseFloat(amount), categoryId: parseInt(categoryId), date, description });
    setAmount(''); setDescription(''); loadData();
  };
  const income = transactions.filter(t => t.categoryType === 'income').reduce((s, t) => s + t.amount, 0);
  const expense = transactions.filter(t => t.categoryType === 'expense').reduce((s, t) => s + t.amount, 0);
  return (
    <div className="min-h-screen bg-slate-50 p-6 text-slate-900 font-sans">
      <div className="max-w-4xl mx-auto space-y-6">
        <header className="bg-white p-6 rounded-xl border border-slate-200">
          <h1 className="text-xl font-bold">Personal Finance Tracker</h1>
          <div className="grid grid-cols-3 gap-4 mt-4 text-center">
            <div className="bg-emerald-50 p-3 rounded-lg"><p className="text-xs text-emerald-600 font-semibold">Income</p><p className="text-lg font-bold text-emerald-700">${income.toFixed(2)}</p></div>
            <div className="bg-rose-50 p-3 rounded-lg"><p className="text-xs text-rose-600 font-semibold">Expenses</p><p className="text-lg font-bold text-rose-700">${expense.toFixed(2)}</p></div>
            <div className="bg-blue-50 p-3 rounded-lg"><p className="text-xs text-blue-600 font-semibold">Net Balance</p><p className="text-lg font-bold text-blue-700">${(income - expense).toFixed(2)}</p></div>
          </div>
        </header>
        <form onSubmit={handleSubmit} className="bg-white p-6 rounded-xl border border-slate-200 grid grid-cols-2 gap-4">
          <input type="number" step="0.01" placeholder="Amount ($)" value={amount} onChange={e=>setAmount(e.target.value)} required className="p-2 border rounded" />
          <select value={categoryId} onChange={e=>setCategoryId(e.target.value)} required className="p-2 border rounded"><option value="">Select Category</option>{categories.map(c=><option key={c.id} value={c.id}>{c.name}</option>)}</select>
          <input type="date" value={date} onChange={e=>setDate(e.target.value)} required className="p-2 border rounded" />
          <input type="text" placeholder="Description" value={description} onChange={e=>setDescription(e.target.value)} className="p-2 border rounded" />
          <button type="submit" className="col-span-2 bg-blue-600 text-white font-semibold py-2 rounded">Add Transaction</button>
        </form>
      </div>
    </div>
  );
}